//:displays rss-feed header
//:[[simple_pie_list?max=10&url=welt.de/feeds/topnews.rss]]
//:displays rss-feeds
//:[[simple_pie?max=10&url=welt.de/feeds/topnews.rss]]
require_once(LEPTON_PATH."/modules/lib_simplepie/library.php");
if (!class_exists('SimplePie')) {
   die('SimplePie nicht geladen');
}
//die ('SimplePie geladen');
if (!isset($url) ) $url='';
if (!isset($max) ) $max=10;

// Set which feed to process.
$feed = new SimplePie();
$feed->set_feed_url('feed://'.$url);


// Run SimplePie.
$feed->init();

$f_link= $feed->get_permalink();
$f_title= $feed->get_title();
$f_desc= $feed->get_description();

// This makes sure that the content is sent to the browser as text/html and the UTF-8 character set (since we didn't change it).
$feed->handle_content_type();

$html  = "<div class='feeder'>"; // start feeder
$html .= "<h1><a href='".$f_link."' target='_blank'>".$f_title."</a></h1>";
//$html .= "<p>".$f_desc."</p>";
$html .= "\n<ul>\n";

$count=0;
foreach ($feed->get_items() as $item){
$html .= "<li class='item'>";
$html .= "<h2 class='item'><a href='".$item->get_permalink()."' target='_blank'>".$item->get_title()."</a></h2>";
$html .= "</li>";
if(++$count >= $max) break;
}


$html .= "</ul>\n";
$html .= "</div>"; // end feeder
unset( $feed);

return $html;