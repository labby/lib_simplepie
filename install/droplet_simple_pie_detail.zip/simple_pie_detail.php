//:displays rss-feed details
//:[[simple_pie_detail?max=10&url=welt.de/feeds/topnews.rss]]
//:displays rss-feed details
//:[[simple_pie_detail?max=10&url=welt.de/feeds/topnews.rss]]
require_once(LEPTON_PATH."/modules/lib_simplepie/library.php");

if (!isset($url) ) $url='';
if (!isset($max) ) $max=5;

// Set which feed to process.
$feed = new SimplePie();
$feed->set_feed_url('feed://'.$url);


// Run SimplePie.
$feed->init();

$f_link= $feed->get_permalink();
$f_title= $feed->get_title();
$f_desc= $feed->get_description();

// This makes sure that the content is sent to the browser as text/html and the UTF-8 character set (since we didn't change it).
$feed->handle_content_type();

$html  = "<div class='feeder'>"; // start feeder

$html .= "<div class='header'>";
$html .= "<h1><a href='".$f_link."' target='_blank'>".$f_title."</a></h1>";
$html .= "<p>".$f_desc."</p>";
$html .= "</div>";


$count=0;
foreach ($feed->get_items() as $item){
$html .= "<div class='item'>";
$html .= "<h2><a href='".$item->get_permalink()."' target='_blank'>".$item->get_title()."</a></h2>";
$html .= "<p>".$item->get_description()."</p>";
$html .= "<p class='small'>Posted: ".$item->get_date('j F Y | g:i a')."</p>";
$html .= "</div>";
if(++$count >= $max) break;
}

$html .= "</div>"; // end feeder
unset( $feed);

return $html;